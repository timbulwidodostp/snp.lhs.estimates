## ----eval=FALSE---------------------------------------------------------------
#  R CMD INSTALL --configure-args="--with-libzbioc" zlibioc_<...>.tar.gz

## ----eval=FALSE---------------------------------------------------------------
#  install.packages("zlibbioc_<...>.tar.gz",
#                     configure.args="--with-libzbioc")

